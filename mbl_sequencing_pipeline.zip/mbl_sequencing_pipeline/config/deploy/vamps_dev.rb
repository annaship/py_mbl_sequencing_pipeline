# VAMPS Dev!!!!
role :app,  "jake.mbl.edu", :primary => true 
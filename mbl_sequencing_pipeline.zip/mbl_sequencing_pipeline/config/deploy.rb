require 'capistrano/ext/multistage'
#require "whenever/capistrano"

set :application, "mbl_sequencing_pipeline"

set :use_sudo, false
# deploy config
set :deploy_via, :remote_cache

# git info
set :scm_passphrase, "oweneego1"
set :user, "jhufnagle"
set :scm, :git  
set :repository,  "git@github.com:johnjh/mbl_sequencing_pipeline"

# the python code is deployed to here
set :deploy_to, "/bioware/seqinfo/bin/python" 



